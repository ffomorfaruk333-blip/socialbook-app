# Social Book Supabase Connection

Project URL is already configured:

https://xsxrcrbcxckicskwppmb.supabase.co

The Supabase Publishable key has already been configured in `lib/main.dart`.

Never put a Supabase `service_role`/secret key in the Flutter app.

Then run:
1. flutter pub get
2. flutter run

If Email confirmation is enabled in Supabase, a new signup may require email confirmation before a session is created.
