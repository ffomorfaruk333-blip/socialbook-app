# Social Book — Supabase Signup Integration

## What is connected
The project now includes a `SocialBookAuth.signUp()` helper using `supabase_flutter`.

It sends:
- email
- password
- full_name metadata

## Important
Do NOT put a Supabase `service_role` key in the Flutter app.

The app must use the Supabase project URL and the public `anon` key.

## Supabase setup
In your Supabase project:
1. Authentication → Providers → Email: enable Email.
2. Authentication → URL Configuration: configure your app/site URL if you use email confirmation.
3. Make sure your database/profile policies are already configured.

## Flutter initialization
Initialize Supabase once before using `SocialBookAuth`:

```dart
await Supabase.initialize(
  url: 'YOUR_SUPABASE_URL',
  anonKey: 'YOUR_SUPABASE_ANON_KEY',
);
```

Then:

```dart
final response = await SocialBookAuth.signUp(
  email: emailController.text,
  password: passwordController.text,
  fullName: nameController.text,
);
```

If email confirmation is enabled, `response.session` may be null until the user confirms the email.

## Security
Never ship the `service_role` key inside the mobile/web client.
