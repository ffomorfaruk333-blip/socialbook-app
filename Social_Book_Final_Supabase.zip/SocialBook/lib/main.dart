import 'package:flutter/material.dart';

void main() => runApp(const SocialBookApp());

class SocialBookApp extends StatelessWidget {
  const SocialBookApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Social Book',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF0B1020),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C5CFF), brightness: Brightness.dark),
    ),
    home: const SocialBookHome(),
  );
}

class SocialBookHome extends StatefulWidget {
  const SocialBookHome({super.key});
  @override State<SocialBookHome> createState() => _SocialBookHomeState();
}

class _SocialBookHomeState extends State<SocialBookHome> {
  int index = 0;
  final pages = const [_Feed(), _Reels(), _Create(), _Chat(), _Profile()];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Social Book', style: TextStyle(fontWeight: FontWeight.bold)),
      actions: [IconButton(
        icon: const Icon(Icons.admin_panel_settings_outlined),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanel())),
      )],
    ),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (i) => setState(() => index = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.movie_outlined), selectedIcon: Icon(Icons.movie), label: 'Reels'),
        NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Create'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chat'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ],
    ),
  );
}

class _Feed extends StatelessWidget {
  const _Feed();
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('What are you thinking?'), subtitle: Text('Create a new post...'))),
      SizedBox(height: 12),
      _Post(name: 'Social Book', text: 'Welcome to Social Book — connect, share and chat in a new way.'),
      _Post(name: 'Creator', text: 'Creator: Omor Faruk'),
    ],
  );
}

class _Post extends StatelessWidget {
  final String name, text;
  const _Post({required this.name, required this.text});
  @override Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const CircleAvatar(child: Icon(Icons.person)), const SizedBox(width: 10), Text(name, style: const TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 14),
        Text(text, style: const TextStyle(fontSize: 16)),
        const Divider(height: 24),
        const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Icon(Icons.favorite_border), Icon(Icons.comment_outlined), Icon(Icons.share_outlined)]),
      ]),
    ),
  );
}

class _Reels extends StatelessWidget { const _Reels(); @override Widget build(BuildContext c) => const Center(child: Text('Reels\n\nShort videos will appear here.', textAlign: TextAlign.center, style: TextStyle(fontSize: 20))); }

class _Create extends StatelessWidget {
  const _Create();
  @override Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Create Post', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 20),
    TextField(maxLines: 6, decoration: InputDecoration(hintText: 'Write something...', border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.publish), label: const Text('Publish')),
  ]);
}

class _Chat extends StatelessWidget { const _Chat(); @override Widget build(BuildContext c) => const Center(child: Text('Chat\n\nRealtime chat will connect to Supabase.'))); }

class _Profile extends StatelessWidget { const _Profile(); @override Widget build(BuildContext c) => const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [CircleAvatar(radius: 48, child: Icon(Icons.person, size: 48)), SizedBox(height: 16), Text('Social Book User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Creator: Omor Faruk')])); }

class AdminPanel extends StatelessWidget {
  const AdminPanel({super.key});
  @override Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Social Book Admin Panel')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Admin Dashboard', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      const _Admin(icon: Icons.people, title: 'Users', sub: 'Manage users and accounts'),
      const _Admin(icon: Icons.article, title: 'Posts', sub: 'Review and manage posts'),
      const _Admin(icon: Icons.movie, title: 'Reels', sub: 'Review reported reels'),
      const _Admin(icon: Icons.flag, title: 'Reports', sub: 'Review reports and moderation'),
      const _Admin(icon: Icons.settings, title: 'App Settings', sub: 'Control app configuration'),
      const _Admin(icon: Icons.campaign, title: 'Announcements', sub: 'Publish announcements'),
      const SizedBox(height: 20),
      const Center(child: Text('Creator: Omor Faruk')),
    ]),
  );
}

class _Admin extends StatelessWidget {
  final IconData icon; final String title, sub;
  const _Admin({required this.icon, required this.title, required this.sub});
  @override Widget build(BuildContext c) => Card(child: ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(sub), trailing: const Icon(Icons.chevron_right)));
}
