# Social Book
Creator: Omor Faruk

Version 0.1 foundation:
- Home Feed
- Reels
- Create Post
- Chat placeholder
- Profile
- Separate Admin Panel entry

Next: Supabase authentication, database, storage, realtime chat, posts, likes, comments, follows, notifications, reels and secure admin controls.

Run with Flutter:
flutter pub get
flutter run
