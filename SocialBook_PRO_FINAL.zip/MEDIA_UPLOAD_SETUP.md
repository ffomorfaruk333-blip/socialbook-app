
# SocialBook Media Upload Setup

The app now contains a reusable image/video upload service.

## Supabase Storage

Create a Storage bucket named:

`media`

For a real production app, prefer a private bucket with signed URLs.
If using a public bucket for initial testing, the app can use `getPublicUrl`.

Recommended folder structure:

`images/<user_id>/...`
`videos/<user_id>/...`

The authenticated user should only be allowed to upload inside their own user-id folder.

## Database

Posts should store at least:

- `content`
- `media_url`
- `media_type`
- `media_path`
- `user_id`
- `created_at`

Do not put service-role keys in the mobile app.

## Limits

- Images: 15 MB maximum
- Videos: 100 MB maximum

The next UI integration step is to connect the existing Create Post page's
Video/Image buttons to `MediaUploadService`, then render the stored media in
the feed.
