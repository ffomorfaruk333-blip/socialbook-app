SocialBook Photo/Video Upload Setup

1. Open Supabase SQL Editor.
2. Paste supabase_setup.sql and run it.
3. Open pubspec.yaml in the GitHub repository and add image_picker under dependencies.
4. Replace lib/main.dart with the supplied socialbook_main.dart.
5. IMPORTANT: keep your existing Supabase URL and publishable/anon key in main.dart. Do NOT put a service_role key in the app.
6. Build the APK from GitHub Actions after committing all changes.

The app's Create Post page will then:
- select a photo from Gallery;
- select a video from Gallery;
- upload media to the post-media bucket;
- insert the post into public.posts.
