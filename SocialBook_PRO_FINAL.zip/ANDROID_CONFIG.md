# Android configuration

Application ID:
`io.socialbook.app`

Email/password authentication does not require OAuth callback configuration.

Facebook/Google/Phone providers are intentionally not enabled in this build. They can be added later after their provider credentials and Supabase configuration are ready.
