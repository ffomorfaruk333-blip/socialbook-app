# SocialBook 1.2.0

A Flutter social-network starter with Supabase authentication, profiles, posts, image/video uploads, likes, comments, search and notifications.

## Required one-time setup
1. Create a Supabase project.
2. Open Supabase SQL Editor and run **SUPABASE_SCHEMA.sql**.
3. Keep Email authentication enabled.
4. Get the project's URL and publishable/anon key.
5. Run:

```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=YOUR_SUPABASE_URL --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

For a release APK:

```bash
flutter build apk --release --dart-define=SUPABASE_URL=YOUR_SUPABASE_URL --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

The app intentionally does not hard-code Supabase secrets into source code. Use `--dart-define` for builds.

## Included features
- Email/password signup, login and password reset
- Real Supabase feed
- Create text, photo and video posts
- 15 MB image / 100 MB video upload limits
- Like/unlike
- Comments
- Search people and posts
- Profile editing
- Delete own posts
- Notifications for likes/comments
- Android internet permission
- Dark Material 3 UI
