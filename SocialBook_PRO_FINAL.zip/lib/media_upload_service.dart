
import 'dart:io';
import 'package:mime/mime.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MediaUploadResult {
  final String path;
  final String publicUrl;
  final String mimeType;
  final int bytes;

  MediaUploadResult({
    required this.path,
    required this.publicUrl,
    required this.mimeType,
    required this.bytes,
  });
}

class MediaUploadService {
  final SupabaseClient client;
  MediaUploadService(this.client);

  Future<MediaUploadResult> upload({
    required File file,
    required String userId,
    required String bucket,
    required String folder,
  }) async {
    final type = lookupMimeType(file.path);
    if (type == null) {
      throw Exception('Unsupported media type');
    }

    final isImage = type.startsWith('image/');
    final isVideo = type.startsWith('video/');
    if (!isImage && !isVideo) {
      throw Exception('Only image and video files are allowed');
    }

    final bytes = await file.length();
    const maxImage = 15 * 1024 * 1024;
    const maxVideo = 100 * 1024 * 1024;
    if (isImage && bytes > maxImage) {
      throw Exception('Image is larger than 15 MB');
    }
    if (isVideo && bytes > maxVideo) {
      throw Exception('Video is larger than 100 MB');
    }

    final ext = file.path.split('.').last.toLowerCase();
    final path =
        '$folder/$userId/${DateTime.now().millisecondsSinceEpoch}.$ext';

    await client.storage.from(bucket).upload(
      path,
      file,
      fileOptions: FileOptions(contentType: type, upsert: false),
    );

    final url = client.storage.from(bucket).getPublicUrl(path);

    return MediaUploadResult(
      path: path,
      publicUrl: url,
      mimeType: type,
      bytes: bytes,
    );
  }
}
