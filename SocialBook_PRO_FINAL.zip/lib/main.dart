import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'media_upload_service.dart';
import 'post_media_view.dart';

const supabaseUrl = 'https://xsxrcrbcxckicskwppmb.supabase.co';
const supabaseAnonKey = 'sb_publishable_0xGXFjbz404LyFWwWo6kzw_wHUgY0NT';
const mediaBucket = 'post-media';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
    runApp(const ConfigErrorApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const SocialBookApp());
}

final supabase = Supabase.instance.client;

class ConfigErrorApp extends StatelessWidget {
  const ConfigErrorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true),
    home: Scaffold(
      body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(
        'SocialBook is not configured yet.\n\nBuild with:\nflutter run --dart-define=SUPABASE_URL=YOUR_URL --dart-define=SUPABASE_ANON_KEY=YOUR_KEY',
        textAlign: TextAlign.center,
      ))),
    ),
  );
}

class SocialBookApp extends StatelessWidget {
  const SocialBookApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SocialBook',
    theme: ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C4DFF), brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xFF07080D),
      useMaterial3: true,
    ),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: supabase.auth.onAuthStateChange,
    builder: (_, snapshot) => supabase.auth.currentSession == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool signup = false, busy = false, obscure = true;

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.length < 6 || (signup && name.text.trim().isEmpty)) {
      _msg('Enter valid information. Password must be at least 6 characters.'); return;
    }
    setState(() => busy = true);
    try {
      if (signup) {
        final res = await supabase.auth.signUp(email: email.text.trim(), password: password.text, data: {'full_name': name.text.trim()});
        if (res.session == null) _msg('Account created. Check your email if confirmation is enabled.');
      } else {
        await supabase.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) { _msg(e.message); }
    catch (e) { _msg('Something went wrong: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> resetPassword() async {
    if (email.text.trim().isEmpty) { _msg('Enter your email first.'); return; }
    try { await supabase.auth.resetPasswordForEmail(email.text.trim()); _msg('Password reset email sent.'); }
    catch (e) { _msg('$e'); }
  }
  void _msg(String s) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(children: [
    Image.asset('assets/logo.png', height: 90, errorBuilder: (_,__,___) => const Icon(Icons.public, size: 80)),
    const SizedBox(height: 12), const Text('SocialBook', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), Text(signup ? 'Create your account' : 'Welcome back', style: const TextStyle(color: Colors.grey)),
    const SizedBox(height: 28),
    if (signup) ...[TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person))), const SizedBox(height: 14)],
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email))),
    const SizedBox(height: 14), TextField(controller: password, obscureText: obscure, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)))),
    const SizedBox(height: 22), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : submit, child: busy ? const CircularProgressIndicator() : Text(signup ? 'Create account' : 'Login'))),
    if (!signup) TextButton(onPressed: resetPassword, child: const Text('Forgot password?')),
    TextButton(onPressed: busy ? null : () => setState(() => signup = !signup), child: Text(signup ? 'Already have an account? Login' : 'Create a new account')),
  ]))));
  @override void dispose(){email.dispose();password.dispose();name.dispose();super.dispose();}
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [FeedPage(), SearchPage(), CreatePostPage(), AlertsPage(), ProfilePage()];
  @override Widget build(BuildContext context) => Scaffold(body: IndexedStack(index:index,children:pages), bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations: const [
    NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'), NavigationDestination(icon:Icon(Icons.search),label:'Search'), NavigationDestination(icon:Icon(Icons.add_box_outlined),selectedIcon:Icon(Icons.add_box),label:'Create'), NavigationDestination(icon:Icon(Icons.notifications_none),selectedIcon:Icon(Icons.notifications),label:'Alerts'), NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')
  ]));
}

class FeedPage extends StatefulWidget { const FeedPage({super.key}); @override State<FeedPage> createState()=>_FeedPageState(); }
class _FeedPageState extends State<FeedPage> {
  Future<List<Map<String,dynamic>>> load() async {
    final rows = await supabase.from('posts').select('*, profiles(id,full_name,username,avatar_url)').order('created_at', ascending:false).limit(50);
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> refresh() async => setState(() {});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('SocialBook',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:()=>setState((){}),icon:const Icon(Icons.refresh)),IconButton(onPressed:()=>supabase.auth.signOut(),icon:const Icon(Icons.logout))]),body:RefreshIndicator(onRefresh:refresh,child:FutureBuilder<List<Map<String,dynamic>>>(future:load(),builder:(context,s){
    if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
    if(s.hasError)return ListView(children:[Padding(padding:const EdgeInsets.all(24),child:Text('Could not load feed.\n${s.error}'))]);
    final posts=s.data??[]; if(posts.isEmpty)return ListView(children:[const SizedBox(height:80),Icon(Icons.dynamic_feed,size:60),const Center(child:Padding(padding:EdgeInsets.all(20),child:Text('No posts yet. Be the first to post!')))]);
    return ListView(padding:const EdgeInsets.all(14),children:[ComposerCard(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CreatePostPage())).then((_)=>setState((){}))),const SizedBox(height:12),...posts.map((p)=>PostCard(post:p,onChanged:()=>setState((){})))];
  })));
}

class ComposerCard extends StatelessWidget { final VoidCallback onTap; const ComposerCard({super.key,required this.onTap}); @override Widget build(BuildContext context){final u=supabase.auth.currentUser; final n=(u?.userMetadata?['full_name']??'You').toString();return Card(child:ListTile(onTap:onTap,leading:CircleAvatar(child:Text(n.isNotEmpty?n[0].toUpperCase():'U')),title:const Text("What's on your mind?"),trailing:const Icon(Icons.image_outlined)));} }

class PostCard extends StatefulWidget { final Map<String,dynamic> post; final VoidCallback onChanged; const PostCard({super.key,required this.post,required this.onChanged}); @override State<PostCard> createState()=>_PostCardState(); }
class _PostCardState extends State<PostCard>{ bool busy=false; int likes=0; bool liked=false;
  @override void initState(){super.initState(); _loadLikes();}
  Future<void> _loadLikes() async { final id=widget.post['id']; final rows=await supabase.from('likes').select('user_id').eq('post_id',id); if(!mounted)return; setState((){likes=rows.length;liked=rows.any((r)=>r['user_id']==supabase.auth.currentUser?.id);}); }
  Future<void> toggleLike() async { if(busy)return; setState(()=>busy=true);try{final uid=supabase.auth.currentUser!.id;final id=widget.post['id'];if(liked){await supabase.from('likes').delete().match({'post_id':id,'user_id':uid});}else{await supabase.from('likes').insert({'post_id':id,'user_id':uid});}await _loadLikes();}catch(e){_msg('$e');}finally{if(mounted)setState(()=>busy=false);}}
  Future<void> deletePost() async {try{await supabase.from('posts').delete().eq('id',widget.post['id']);widget.onChanged();}catch(e){_msg('$e');}}
  void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  @override Widget build(BuildContext context){final p=widget.post;final profile=(p['profiles'] as Map?)?.cast<String,dynamic>()??{};final name=(profile['full_name']??profile['username']??'SocialBook User').toString();final uid=supabase.auth.currentUser?.id;final mine=p['user_id']==uid;final media=p['media_url'] as String?;return Card(margin:const EdgeInsets.only(bottom:14),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[CircleAvatar(child:Text(name.isNotEmpty?name[0].toUpperCase():'U')),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontWeight:FontWeight.bold)),Text(_time(p['created_at']),style:const TextStyle(fontSize:12,color:Colors.grey))])),if(mine)PopupMenuButton<String>(onSelected:(v){if(v=='delete')deletePost();},itemBuilder:(_)=>const [PopupMenuItem(value:'delete',child:Text('Delete post'))])]),if((p['content']??'').toString().isNotEmpty)...[const SizedBox(height:12),Text(p['content'].toString(),style:const TextStyle(fontSize:16))],if(media!=null)...[const SizedBox(height:12),PostMediaView(url:media,mediaType:(p['media_type']??'').toString())],const SizedBox(height:8),Row(children:[Text('$likes likes',style:const TextStyle(color:Colors.grey)),const Spacer(),TextButton.icon(onPressed:()=>showComments(context,p['id']),icon:const Icon(Icons.comment_outlined),label:const Text('Comments'))]),const Divider(height:1),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[TextButton.icon(onPressed:busy?null:toggleLike,icon:Icon(liked?Icons.favorite:Icons.favorite_border,color:liked?Colors.red:null),label:Text(liked?'Liked':'Like')),TextButton.icon(onPressed:()=>showComments(context,p['id']),icon:const Icon(Icons.comment_outlined),label:const Text('Comment')),TextButton.icon(onPressed:()=>_copyPost(p['content']?.toString()??''),icon:const Icon(Icons.share_outlined),label:const Text('Share'))])])));}
  Future<void> _copyPost(String text)async{await Clipboard.setData(ClipboardData(text:text));_msg('Post text copied.');}
}
String _time(dynamic raw){final d=DateTime.tryParse(raw?.toString()??'')?.toLocal();if(d==null)return '';final diff=DateTime.now().difference(d);if(diff.inMinutes<1)return 'just now';if(diff.inHours<1)return '${diff.inMinutes}m';if(diff.inDays<1)return '${diff.inHours}h';if(diff.inDays<7)return '${diff.inDays}d';return '${d.day}/${d.month}/${d.year}';}

Future<void> showComments(BuildContext context,dynamic postId) async {showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>CommentsSheet(postId:postId));}
class CommentsSheet extends StatefulWidget { final dynamic postId; const CommentsSheet({super.key,required this.postId}); @override State<CommentsSheet> createState()=>_CommentsSheetState(); }
class _CommentsSheetState extends State<CommentsSheet>{final c=TextEditingController();Future<List<Map<String,dynamic>>> load()async{final r=await supabase.from('comments').select('*, profiles!comments_user_id_fkey(full_name,username,avatar_url)').eq('post_id',widget.postId).order('created_at');return List<Map<String,dynamic>>.from(r);}Future<void> add()async{if(c.text.trim().isEmpty)return;await supabase.from('comments').insert({'post_id':widget.postId,'user_id':supabase.auth.currentUser!.id,'content':c.text.trim()});c.clear();setState((){});} @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(context).viewInsets.bottom),child:SizedBox(height:MediaQuery.of(context).size.height*.72,child:Column(children:[const Padding(padding:EdgeInsets.all(16),child:Text('Comments',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),Expanded(child:FutureBuilder(future:load(),builder:(context,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final rows=s.data!;if(rows.isEmpty)return const Center(child:Text('No comments yet.'));return ListView(children:rows.map((r){final p=(r['profiles'] as Map?)?.cast<String,dynamic>()??{};return ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text((p['full_name']??p['username']??'User').toString()),subtitle:Text(r['content'].toString()));}).toList());})),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:c,decoration:const InputDecoration(hintText:'Write a comment...',border:OutlineInputBorder()))),IconButton(onPressed:add,icon:const Icon(Icons.send))])))])));@override void dispose(){c.dispose();super.dispose();}}

class CreatePostPage extends StatefulWidget { const CreatePostPage({super.key}); @override State<CreatePostPage> createState()=>_CreatePostPageState(); }
class _CreatePostPageState extends State<CreatePostPage>{final picker=ImagePicker();final c=TextEditingController();XFile? file;bool video=false,busy=false;Future<void>pick(bool isVideo)async{final f=isVideo?await picker.pickVideo(source:ImageSource.gallery,maxDuration:const Duration(minutes:5)):await picker.pickImage(source:ImageSource.gallery,imageQuality:90);if(f!=null)setState((){file=f;video=isVideo;});}Future<void>publish()async{if(c.text.trim().isEmpty&&file==null){_msg('Write something or select media.');return;}setState(()=>busy=true);try{String? url,type;if(file!=null){final r=await MediaUploadService(supabase).upload(file:File(file!.path),userId:supabase.auth.currentUser!.id,bucket:mediaBucket,folder:'posts');url=r.publicUrl;type=r.mimeType.startsWith('video/')?'video':'image';}await supabase.from('posts').insert({'user_id':supabase.auth.currentUser!.id,'content':c.text.trim(),'media_url':url,'media_type':type});if(mounted){c.clear();setState(()=>file=null);_msg('Post published!');}}catch(e){_msg('Post failed: $e');}finally{if(mounted)setState(()=>busy=false);}}void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Create Post')),body:ListView(padding:const EdgeInsets.all(18),children:[TextField(controller:c,maxLines:6,maxLength:5000,decoration:const InputDecoration(hintText:"What's on your mind?",border:OutlineInputBorder())),if(file!=null)...[const SizedBox(height:12),video?Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),color:const Color(0xFF141720)),child:Text(file!.name)):ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(File(file!.path),height:260,fit:BoxFit.cover))],const SizedBox(height:14),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:busy?null:()=>pick(false),icon:const Icon(Icons.image),label:const Text('Photo'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:busy?null:()=>pick(true),icon:const Icon(Icons.video_file),label:const Text('Video')))]),const SizedBox(height:14),FilledButton.icon(onPressed:busy?null:publish,icon:busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send),label:Text(busy?'Publishing...':'Publish'))]));@override void dispose(){c.dispose();super.dispose();}}

class SearchPage extends StatefulWidget{const SearchPage({super.key});@override State<SearchPage>createState()=>_SearchPageState();}
class _SearchPageState extends State<SearchPage>{final q=TextEditingController();List<Map<String,dynamic>> users=[];List<Map<String,dynamic>> posts=[];bool loading=false;Future<void>search()async{final s=q.text.trim();if(s.isEmpty){setState(()=>users=[]);return;}setState(()=>loading=true);try{final u=await supabase.from('profiles').select('id,full_name,username,avatar_url').or('full_name.ilike.%$s%,username.ilike.%$s%').limit(20);final p=await supabase.from('posts').select('*, profiles(full_name,username)').ilike('content','%$s%').order('created_at',ascending:false).limit(20);setState((){users=List<Map<String,dynamic>>.from(u);posts=List<Map<String,dynamic>>.from(p);});}catch(e){_msg('$e');}finally{if(mounted)setState(()=>loading=false);}}void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:TextField(controller:q,onSubmitted:(_)=>search(),decoration:const InputDecoration(hintText:'Search people or posts',border:InputBorder.none),textInputAction:TextInputAction.search),actions:[IconButton(onPressed:search,icon:const Icon(Icons.search))]),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(12),children:[if(users.isNotEmpty)const Padding(padding:EdgeInsets.all(8),child:Text('People',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),...users.map((u)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text((u['full_name']??'User').toString()),subtitle:Text(u['username']==null?'': '@${u['username']}'))),if(posts.isNotEmpty)const Padding(padding:EdgeInsets.all(8),child:Text('Posts',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),...posts.map((p)=>PostCard(post:p,onChanged:()=>setState((){}))),if(users.isEmpty&&posts.isEmpty&&q.text.isNotEmpty)const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('No results')))]);@override void dispose(){q.dispose();super.dispose();}}

class AlertsPage extends StatelessWidget{const AlertsPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Alerts')),body:FutureBuilder<List<Map<String,dynamic>>>(future:supabase.from('notifications').select('*, actor:profiles!notifications_actor_id_fkey(full_name,username)').eq('user_id',supabase.auth.currentUser!.id).order('created_at',ascending:false).limit(50).then((r)=>List<Map<String,dynamic>>.from(r)),builder:(context,s){if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());if(s.hasError)return Center(child:Text('Alerts unavailable'));final rows=s.data??[];if(rows.isEmpty)return const Center(child:Text('No new alerts'));return ListView(children:rows.map((n){final a=(n['actor'] as Map?)?.cast<String,dynamic>()??{};return ListTile(leading:const CircleAvatar(child:Icon(Icons.notifications)),title:Text('${a['full_name']??'Someone'} ${n['message']??''}'),subtitle:Text(_time(n['created_at'])));}).toList());}));}}

class ProfilePage extends StatefulWidget{const ProfilePage({super.key});@override State<ProfilePage>createState()=>_ProfilePageState();}
class _ProfilePageState extends State<ProfilePage>{Map<String,dynamic>? profile;int count=0;@override void initState(){super.initState();load();}Future<void>load()async{final u=supabase.auth.currentUser;if(u==null)return;final p=await supabase.from('profiles').select().eq('id',u.id).maybeSingle();final c=await supabase.from('posts').select('id').eq('user_id',u.id).count(CountOption.exact);if(mounted)setState((){profile=p;count=c.count;});}Future<void>edit()async{final name=TextEditingController(text:(profile?['full_name']??'').toString());final username=TextEditingController(text:(profile?['username']??'').toString());final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Edit profile'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Full name')),TextField(controller:username,decoration:const InputDecoration(labelText:'Username'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Save'))]));if(ok==true){await supabase.from('profiles').update({'full_name':name.text.trim(),'username':username.text.trim().toLowerCase()}).eq('id',supabase.auth.currentUser!.id);load();}}@override Widget build(BuildContext context){final u=supabase.auth.currentUser;final n=(profile?['full_name']??u?.email?.split('@').first??'User').toString();return Scaffold(appBar:AppBar(title:const Text('Profile')),body:ListView(padding:const EdgeInsets.all(22),children:[const CircleAvatar(radius:60,child:Icon(Icons.person,size:64)),const SizedBox(height:16),Center(child:Text(n,style:const TextStyle(fontSize:26,fontWeight:FontWeight.bold))),Center(child:Text(u?.email??'',style:const TextStyle(color:Colors.grey))),const SizedBox(height:18),Center(child:Text('$count posts',style:const TextStyle(fontWeight:FontWeight.bold))),const SizedBox(height:24),ListTile(leading:const Icon(Icons.edit),title:const Text('Edit Profile'),onTap:edit),ListTile(leading:const Icon(Icons.bookmark_outline),title:const Text('Saved Posts'),onTap:()=>_msg('Saved posts are coming next.')),ListTile(leading:const Icon(Icons.settings_outlined),title:const Text('Settings'),onTap:()=>_msg('Settings are ready for the next update.')),ListTile(leading:const Icon(Icons.logout,color:Colors.red),title:const Text('Logout',style:TextStyle(color:Colors.red)),onTap:()=>supabase.auth.signOut())]));}void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
