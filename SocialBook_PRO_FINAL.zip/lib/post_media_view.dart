import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class PostMediaView extends StatefulWidget {
  final String url;
  final String mediaType;
  const PostMediaView({super.key, required this.url, required this.mediaType});
  @override State<PostMediaView> createState() => _PostMediaViewState();
}
class _PostMediaViewState extends State<PostMediaView> {
  VideoPlayerController? c;
  @override void initState(){super.initState(); if(widget.mediaType=='video'){c=VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_){if(mounted)setState((){});});}}
  @override void dispose(){c?.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    if(widget.mediaType!='video')return ClipRRect(borderRadius:BorderRadius.circular(14),child:Image.network(widget.url,width:double.infinity,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const SizedBox(height:180,child:Center(child:Icon(Icons.broken_image_outlined)))));
    final v=c;if(v==null||!v.value.isInitialized)return const SizedBox(height:220,child:Center(child:CircularProgressIndicator()));
    return ClipRRect(borderRadius:BorderRadius.circular(14),child:AspectRatio(aspectRatio:v.value.aspectRatio==0?16/9:v.value.aspectRatio,child:Stack(alignment:Alignment.center,children:[VideoPlayer(v),IconButton.filled(onPressed:()=>setState(()=>v.value.isPlaying?v.pause():v.play()),icon:Icon(v.value.isPlaying?Icons.pause:Icons.play_arrow))])));
  }
}
