# SocialBook — Real Supabase Backend Setup

The app now uses Supabase for posts, likes, comments, search and profile data. There is no in-memory `appPosts` feed.

## 1. Run the database SQL

Open Supabase Dashboard -> SQL Editor -> New query.

Open `SUPABASE_SCHEMA.sql`, copy the entire file, paste it into SQL Editor and press Run.

The script creates:
- `profiles`
- `posts`
- `likes`
- `comments`

It also creates the Auth-user -> profile trigger and Row Level Security policies.

## 2. Email login

Keep Authentication -> Providers -> Email enabled. Facebook/Phone are intentionally not required in this version.

If email confirmation is enabled, a newly registered user must confirm the email before logging in.

## 3. What the app now does

- Create Post writes to `posts`.
- Home feed reads real posts from Supabase.
- Like/Unlike writes to `likes`.
- Comments read/write `comments`.
- Search reads `profiles` and `posts`.
- Profile post count reads the real `posts` table.

## 4. Important security rule

Never put a Supabase service-role/secret key inside the Flutter app. Only the public/publishable key belongs in the client.

## 5. Re-run safe

The SQL is designed to be re-run. If the realtime publication already contains a table, Supabase may report that specific `alter publication` line as already existing; the tables/policies themselves remain fine.
