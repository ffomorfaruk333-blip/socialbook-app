# SocialBook Final Release

- Flutter + Supabase
- Supabase URL configured
- Publishable key configured
- Existing post schema compatibility fixed for `user_id`
- Photo/video posting retained
- Login/signup/forgot password retained
- Feed, likes, comments, search, alerts and profile retained
- No DROP TABLE / destructive database migration included

Build with the included GitHub Actions workflow or a local Flutter SDK.
