# SocialBook — build the APK

The project is already configured with the supplied Supabase Project URL and publishable key.

## Easiest way to build the APK

1. Create a GitHub repository.
2. Upload this whole project to the repository.
3. Open **Actions** → **Build SocialBook APK** → **Run workflow**.
4. Wait for the build to finish.
5. Open the completed workflow run and download the artifact named **SocialBook-release-apk**.

The workflow runs `flutter create --platforms=android .` first to restore any missing Android/Gradle wrapper files, then builds the release APK.

## Important

The app source was adjusted to match the existing live database structure observed during setup, where posts use `user_id` rather than `author_id`. No destructive database migration is included here.
