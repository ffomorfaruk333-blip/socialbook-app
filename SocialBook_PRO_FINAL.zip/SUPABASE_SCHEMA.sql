-- SocialBook production schema. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

alter table if exists public.profiles add column if not exists username text;
alter table if exists public.profiles add column if not exists is_admin boolean not null default false;
alter table if exists public.profiles add column if not exists avatar_url text;
alter table if exists public.profiles add column if not exists created_at timestamptz default now();
alter table if exists public.profiles add column if not exists updated_at timestamptz default now();

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '' check (char_length(content) <= 5000),
  media_url text,
  media_type text check (media_type in ('image','video') or media_type is null),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.posts add column if not exists author_id uuid;
-- If an older SocialBook build used user_id, copy it into the new author_id field.
do $$ begin if exists (select 1 from information_schema.columns where table_schema='public' and table_name='posts' and column_name='user_id') then update public.posts set author_id=user_id where author_id is null; end if; end $$;
alter table public.posts add column if not exists media_url text;
alter table public.posts add column if not exists media_type text;

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(), post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check(char_length(trim(content)) between 1 and 2000), created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null, post_id uuid references public.posts(id) on delete cascade,
  type text not null, message text not null default '', read_at timestamptz, created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_author_id_idx on public.posts(author_id);
create index if not exists likes_post_id_idx on public.likes(post_id);
create index if not exists comments_post_id_idx on public.comments(post_id,created_at);
create index if not exists notifications_user_id_idx on public.notifications(user_id,created_at desc);
create unique index if not exists profiles_username_unique on public.profiles(lower(username)) where username is not null and username <> '';

create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end; $$;
drop trigger if exists posts_set_updated_at on public.posts;
create trigger posts_set_updated_at before update on public.posts for each row execute procedure public.set_updated_at();


create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name) values(new.id,coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'),''),'SocialBook User')) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
insert into public.profiles(id,full_name) select id,coalesce(nullif(trim(raw_user_meta_data->>'full_name'),''),'SocialBook User') from auth.users on conflict(id) do nothing;

create or replace function public.notify_like() returns trigger language plpgsql security definer set search_path=public as $$
declare owner uuid; begin select author_id into owner from public.posts where id=new.post_id; if owner is not null and owner<>new.user_id then insert into public.notifications(user_id,actor_id,post_id,type,message) values(owner,new.user_id,new.post_id,'like','liked your post'); end if; return new; end; $$;
drop trigger if exists likes_notification on public.likes;
create trigger likes_notification after insert on public.likes for each row execute procedure public.notify_like();

create or replace function public.notify_comment() returns trigger language plpgsql security definer set search_path=public as $$
declare owner uuid; begin select author_id into owner from public.posts where id=new.post_id; if owner is not null and owner<>new.user_id then insert into public.notifications(user_id,actor_id,post_id,type,message) values(owner,new.user_id,new.post_id,'comment','commented on your post'); end if; return new; end; $$;
drop trigger if exists comments_notification on public.comments;
create trigger comments_notification after insert on public.comments for each row execute procedure public.notify_comment();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.notifications enable row level security;

drop policy if exists profiles_select_authenticated on public.profiles;
create policy profiles_select_authenticated on public.profiles for select to authenticated using(true);
drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own on public.profiles for insert to authenticated with check(id=auth.uid());
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());

drop policy if exists posts_select_authenticated on public.posts;
create policy posts_select_authenticated on public.posts for select to authenticated using(true);
drop policy if exists posts_insert_own on public.posts;
create policy posts_insert_own on public.posts for insert to authenticated with check(author_id=auth.uid());
drop policy if exists posts_update_own on public.posts;
create policy posts_update_own on public.posts for update to authenticated using(author_id=auth.uid()) with check(author_id=auth.uid());
drop policy if exists posts_delete_own on public.posts;
create policy posts_delete_own on public.posts for delete to authenticated using(author_id=auth.uid());

drop policy if exists likes_select_authenticated on public.likes;
create policy likes_select_authenticated on public.likes for select to authenticated using(true);
drop policy if exists likes_insert_own on public.likes;
create policy likes_insert_own on public.likes for insert to authenticated with check(user_id=auth.uid());
drop policy if exists likes_delete_own on public.likes;
create policy likes_delete_own on public.likes for delete to authenticated using(user_id=auth.uid());

drop policy if exists comments_select_authenticated on public.comments;
create policy comments_select_authenticated on public.comments for select to authenticated using(true);
drop policy if exists comments_insert_own on public.comments;
create policy comments_insert_own on public.comments for insert to authenticated with check(user_id=auth.uid());
drop policy if exists comments_update_own on public.comments;
create policy comments_update_own on public.comments for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists comments_delete_own on public.comments;
create policy comments_delete_own on public.comments for delete to authenticated using(user_id=auth.uid());

drop policy if exists notifications_select_own on public.notifications;
create policy notifications_select_own on public.notifications for select to authenticated using(user_id=auth.uid());
drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

insert into storage.buckets(id,name,public) values('post-media','post-media',true) on conflict(id) do update set public=true;
drop policy if exists post_media_upload_authenticated on storage.objects;
create policy post_media_upload_authenticated on storage.objects for insert to authenticated with check(bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists post_media_read_public on storage.objects;
create policy post_media_read_public on storage.objects for select to public using(bucket_id='post-media');
drop policy if exists post_media_delete_own on storage.objects;
create policy post_media_delete_own on storage.objects for delete to authenticated using(bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);

-- Realtime: run these if your project does not already have them enabled.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='posts') then alter publication supabase_realtime add table public.posts; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='likes') then alter publication supabase_realtime add table public.likes; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='comments') then alter publication supabase_realtime add table public.comments; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='notifications') then alter publication supabase_realtime add table public.notifications; end if;
end $$;
