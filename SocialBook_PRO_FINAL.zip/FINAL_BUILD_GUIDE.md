# SocialBook — Final Android Build

This is the cleaned Flutter project. The existing Supabase-backed app code and database-compatible `user_id` post flow are preserved.

## Build on GitHub (phone-friendly)

1. Upload the **contents of this ZIP** to the root of a GitHub repository.
2. Open **Actions**.
3. Select **Build SocialBook APK**.
4. Press **Run workflow** (or push to `main` to trigger it automatically).
5. Wait for the green check.
6. Open the completed workflow run.
7. Under **Artifacts**, download `SocialBook-release-apk`.
8. The downloaded ZIP contains `app-release.apk`.

Do not upload a Supabase service-role key. The app uses the public publishable/anon key.

## Important

The project already contains its Supabase URL/key and does not require a new database migration for the existing schema.
