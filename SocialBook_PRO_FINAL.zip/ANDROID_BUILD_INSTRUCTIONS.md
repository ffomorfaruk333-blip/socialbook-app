# Android build

Install Flutter and Android Studio on a computer, then from the project directory:

```bash
flutter pub get
flutter analyze
flutter build apk --release --dart-define=SUPABASE_URL=YOUR_SUPABASE_URL --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

Do not put the Supabase service-role key in the app. The mobile app must use the public publishable/anon key with RLS enabled.
