import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'media_upload_service.dart';
import 'post_media_view.dart';

const String supabaseUrl = 'https://xsxrcrbcxckicskwppmb.supabase.co';
const String supabasePublishableKey = 'sb_publishable_0xGXFjbz404LyFWwWo6kzw_wHUgY0NT';
const String mediaBucket = 'post-media';

final supabase = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabasePublishableKey);
  runApp(const SocialBookApp());
}

class SocialBookApp extends StatelessWidget {
  const SocialBookApp({super.key});
  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF8B5CF6);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SocialBook',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07080D),
        colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
        cardTheme: const CardThemeData(color: Color(0xFF11131B), margin: EdgeInsets.zero),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF11131B),
          border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16)), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16)), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16)), borderSide: BorderSide(color: purple, width: 1.4)),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: supabase.auth.onAuthStateChange,
        builder: (_, snap) {
          final session = snap.data?.session ?? supabase.auth.currentSession;
          return session == null ? const AuthPage() : const HomeShell();
        },
      );
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final fullName = TextEditingController();
  final username = TextEditingController();
  bool signup = false, loading = false, obscure = true;

  Future<void> submit() async {
    final e = email.text.trim();
    final p = password.text;
    if (e.isEmpty || p.length < 6 || (signup && fullName.text.trim().isEmpty)) {
      _msg('সব প্রয়োজনীয় তথ্য দিন। Password কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }
    setState(() => loading = true);
    try {
      if (signup) {
        final r = await supabase.auth.signUp(email: e, password: p, data: {
          'full_name': fullName.text.trim(),
          'username': username.text.trim(),
        });
        if (!mounted) return;
        if (r.session == null) {
          _msg('Account তৈরি হয়েছে। Email confirm করে তারপর Login করুন।');
          setState(() => signup = false);
        } else {
          _msg('Account successfully created 🎉');
        }
      } else {
        await supabase.auth.signInWithPassword(email: e, password: p);
      }
    } on AuthException catch (e) {
      _msg(e.message);
    } catch (e) {
      _msg('কাজটি সম্পন্ন করা যায়নি: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _msg(String s) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(children: [
                  Container(width: 88, height: 88, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFFB388FF)]), borderRadius: BorderRadius.circular(28)), child: const Icon(Icons.people_alt_rounded, size: 48)),
                  const SizedBox(height: 20),
                  const Text('SocialBook', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(signup ? 'Create your professional social profile' : 'Welcome back to your community', style: TextStyle(color: Colors.grey.shade400)),
                  const SizedBox(height: 32),
                  if (signup) ...[
                    TextField(controller: fullName, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 14),
                    TextField(controller: username, decoration: const InputDecoration(labelText: 'Username (optional)', prefixIcon: Icon(Icons.alternate_email))),
                    const SizedBox(height: 14),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 14),
                  TextField(controller: password, obscureText: obscure, onSubmitted: (_) => loading ? null : submit(), decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined))),
                  const SizedBox(height: 22),
                  SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: loading ? null : submit, child: loading ? const CircularProgressIndicator() : Text(signup ? 'Create Account' : 'Log In', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)))),
                  TextButton(onPressed: loading ? null : () => setState(() => signup = !signup), child: Text(signup ? 'Already have an account? Log in' : 'New to SocialBook? Create an account')),
                ]),
              ),
            ),
          ),
        ),
      );

  @override
  void dispose() { email.dispose(); password.dispose(); fullName.dispose(); username.dispose(); super.dispose(); }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  late final List<Widget> pages = [
    const FeedPage(), const SearchPage(), const CreatePostPage(), const AlertsPage(), const ProfilePage(),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Create'),
            NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Alerts'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      );
}

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});
  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  late Stream<List<Map<String, dynamic>>> stream;
  final Map<String, Map<String, dynamic>> profiles = {};
  final Set<String> liked = {};
  final Map<String, int> likeCounts = {};
  final Map<String, int> commentCounts = {};
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    stream = supabase.from('posts').stream(primaryKey: ['id']).order('created_at', ascending: false);
    _sub = stream.listen((rows) { if (mounted) _hydrate(rows); });
  }

  Future<void> _hydrate(List<Map<String, dynamic>> rows) async {
    final ids = rows.map((p) => p['user_id']?.toString() ?? p['author_id']?.toString()).whereType<String>().toSet().toList();
    if (ids.isNotEmpty) {
      try {
        final ps = await supabase.from('profiles').select('id,full_name,username,avatar_url').inFilter('id', ids);
        for (final p in ps) profiles[p['id'].toString()] = Map<String, dynamic>.from(p);
      } catch (_) {}
    }
    final postIds = rows.map((p) => p['id'].toString()).toList();
    if (postIds.isNotEmpty) {
      try {
        final ls = await supabase.from('likes').select('post_id,user_id').inFilter('post_id', postIds);
        likeCounts.clear(); liked.clear();
        final me = supabase.auth.currentUser?.id;
        for (final l in ls) { final id = l['post_id'].toString(); likeCounts[id] = (likeCounts[id] ?? 0) + 1; if (l['user_id']?.toString() == me) liked.add(id); }
        final cs = await supabase.from('comments').select('post_id').inFilter('post_id', postIds);
        commentCounts.clear(); for (final c in cs) { final id = c['post_id'].toString(); commentCounts[id] = (commentCounts[id] ?? 0) + 1; }
      } catch (_) {}
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() { _sub?.cancel(); super.dispose(); }

  String _name(String? id) {
    final p = id == null ? null : profiles[id];
    final n = p?['full_name']?.toString().trim();
    if (n != null && n.isNotEmpty) return n;
    final u = p?['username']?.toString().trim();
    if (u != null && u.isNotEmpty) return '@$u';
    return 'SocialBook User';
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('SocialBook', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 24)),
          actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage())), icon: const Icon(Icons.search)), IconButton(onPressed: () => supabase.auth.signOut(), icon: const Icon(Icons.logout_outlined))],
        ),
        body: StreamBuilder<List<Map<String, dynamic>>>(
          stream: stream,
          builder: (context, snap) {
            if (snap.hasError) return _ErrorState(onRetry: () => setState(() {}));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final posts = snap.data!;
            return RefreshIndicator(
              onRefresh: () async => _hydrate(posts),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 28),
                children: [
                  _HeroBanner(), const SizedBox(height: 14), const ComposerCard(), const SizedBox(height: 16),
                  if (posts.isEmpty) const _EmptyState() else ...posts.map((p) => PostCard(
                    post: p, author: _name(p['user_id']?.toString() ?? p['author_id']?.toString()),
                    profile: profiles[p['user_id']?.toString() ?? p['author_id']?.toString()],
                    liked: liked.contains(p['id'].toString()), likes: likeCounts[p['id'].toString()] ?? 0, comments: commentCounts[p['id'].toString()] ?? 0,
                    onLike: () => _toggleLike(p['id'].toString()), onComments: () => _comments(p),
                  )),
                ],
              ),
            );
          },
        ),
      );

  Future<void> _toggleLike(String postId) async {
    final uid = supabase.auth.currentUser?.id; if (uid == null) return;
    try {
      if (liked.contains(postId)) await supabase.from('likes').delete().match({'post_id': postId, 'user_id': uid});
      else await supabase.from('likes').insert({'post_id': postId, 'user_id': uid});
      await _hydrate((await supabase.from('posts').select()) as List<Map<String,dynamic>>);
    } catch (e) { if (mounted) _msg('Like করা যায়নি: $e'); }
  }

  Future<void> _comments(Map<String,dynamic> post) async {
    final id = post['id'].toString();
    final controller = TextEditingController();
    final result = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, backgroundColor: const Color(0xFF0D0F15), builder: (_) => _CommentsSheet(postId: id, controller: controller));
    controller.dispose();
    if (result == true && mounted) setState(() {});
  }

  void _msg(String s) => ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating));
}

class _HeroBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF241447), Color(0xFF121827)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
        child: const Row(children: [Icon(Icons.auto_awesome, color: Color(0xFFB388FF), size: 34), SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Your community. Your voice.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), SizedBox(height: 5), Text('Share moments, discover people and connect.', style: TextStyle(color: Colors.white60))]))]),
      );
}

class ComposerCard extends StatelessWidget {
  const ComposerCard({super.key});
  @override
  Widget build(BuildContext context) => Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatePostPage())),
          child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [UserAvatar(user: supabase.auth.currentUser, radius: 24), const SizedBox(width: 12), const Expanded(child: Text("What's on your mind?", style: TextStyle(color: Colors.white60))), const Icon(Icons.image_outlined, color: Color(0xFF9B6DFF))])),
        ),
      );
}

class PostCard extends StatelessWidget {
  final Map<String,dynamic> post; final String author; final Map<String,dynamic>? profile; final bool liked; final int likes, comments; final VoidCallback onLike, onComments;
  const PostCard({super.key, required this.post, required this.author, required this.profile, required this.liked, required this.likes, required this.comments, required this.onLike, required this.onComments});
  @override
  Widget build(BuildContext context) {
    final text = post['content']?.toString() ?? '';
    final url = post['media_url']?.toString();
    final type = post['media_type']?.toString() ?? '';
    final mine = post['user_id']?.toString() == supabase.auth.currentUser?.id || post['author_id']?.toString() == supabase.auth.currentUser?.id;
    final time = DateTime.tryParse(post['created_at']?.toString() ?? '')?.toLocal();
    return Card(
      margin: const EdgeInsets.only(bottom: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [UserAvatar(url: profile?['avatar_url']?.toString(), name: author, radius: 23), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(author, style: const TextStyle(fontWeight: FontWeight.w800)), Text(time == null ? 'Just now' : _relative(time), style: const TextStyle(fontSize: 12, color: Colors.white45))])), IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz))]),
        if (text.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(2, 13, 2, 13), child: Text(text, style: const TextStyle(fontSize: 16, height: 1.45))),
        if (url != null && url.isNotEmpty && type.isNotEmpty) PostMediaView(url: url, mediaType: type),
        const SizedBox(height: 12),
        Row(children: [Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.pinkAccent : Colors.white54, size: 19), const SizedBox(width: 5), Text('$likes'), const SizedBox(width: 16), const Icon(Icons.mode_comment_outlined, size: 18, color: Colors.white54), const SizedBox(width: 5), Text('$comments'), const Spacer(), const Icon(Icons.public, size: 15, color: Colors.white38), const SizedBox(width: 4), const Text('Public', style: TextStyle(fontSize: 12, color: Colors.white38))]),
        const Divider(height: 22),
        Row(children: [Expanded(child: _ActionButton(icon: liked ? Icons.favorite : Icons.favorite_border, label: 'Like', color: liked ? Colors.pinkAccent : null, onTap: onLike)), Expanded(child: _ActionButton(icon: Icons.comment_outlined, label: 'Comment', onTap: onComments)), Expanded(child: _ActionButton(icon: Icons.share_outlined, label: 'Share', onTap: () {}))]),
        if (mine) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Your post', style: TextStyle(fontSize: 11, color: Colors.white30))),
      ])),
    );
  }
}

String _relative(DateTime t) { final d=DateTime.now().difference(t); if(d.inSeconds<60)return '${d.inSeconds}s'; if(d.inMinutes<60)return '${d.inMinutes}m'; if(d.inHours<24)return '${d.inHours}h'; if(d.inDays<7)return '${d.inDays}d'; return '${t.day}/${t.month}/${t.year}'; }

class _ActionButton extends StatelessWidget { final IconData icon; final String label; final VoidCallback onTap; final Color? color; const _ActionButton({required this.icon,required this.label,required this.onTap,this.color}); @override Widget build(BuildContext context)=>TextButton.icon(onPressed:onTap,icon:Icon(icon,size:19,color:color),label:Text(label)); }

class UserAvatar extends StatelessWidget {
  final User? user; final String? url; final String? name; final double radius;
  const UserAvatar({super.key,this.user,this.url,this.name,required this.radius});
  @override Widget build(BuildContext context){ final n=name ?? user?.userMetadata?['full_name']?.toString() ?? user?.email?.split('@').first ?? 'S'; final letter=n.isEmpty?'S':n[0].toUpperCase(); return CircleAvatar(radius:radius, backgroundColor: const Color(0xFF382064), backgroundImage: (url!=null && url!.isNotEmpty)?NetworkImage(url!):null, child:(url==null||url!.isEmpty)?Text(letter,style:const TextStyle(fontWeight:FontWeight.bold)):null); }
}

class CreatePostPage extends StatefulWidget { const CreatePostPage({super.key}); @override State<CreatePostPage> createState()=>_CreatePostPageState(); }
class _CreatePostPageState extends State<CreatePostPage>{
  final picker=ImagePicker(); final controller=TextEditingController(); XFile? photo,video; bool uploading=false;
  Future<void> pickPhoto() async { final f=await picker.pickImage(source:ImageSource.gallery,imageQuality:88); if(f!=null)setState(() { photo=f; video=null; }); }
  Future<void> pickVideo() async { final f=await picker.pickVideo(source:ImageSource.gallery,maxDuration:const Duration(minutes:5)); if(f!=null)setState(() { video=f; photo=null; }); }
  Future<void> publish() async { final user=supabase.auth.currentUser; if(user==null)return; final text=controller.text.trim(); if(text.isEmpty&&photo==null&&video==null){_msg('Post লিখুন বা media নির্বাচন করুন');return;} setState(()=>uploading=true); try{String? mediaUrl;String? mediaType;if(photo!=null){final r=await MediaUploadService(supabase).upload(file:File(photo!.path),userId:user.id,bucket:mediaBucket,folder:'posts');mediaUrl=r.publicUrl;mediaType=r.mimeType;}else if(video!=null){final r=await MediaUploadService(supabase).upload(file:File(video!.path),userId:user.id,bucket:mediaBucket,folder:'posts');mediaUrl=r.publicUrl;mediaType=r.mimeType;} await supabase.from('posts').insert({'user_id':user.id,'content':text,'media_url':mediaUrl,'media_type':mediaType}); if(mounted){_msg('Post published successfully 🎉');controller.clear();setState(()=>photo=video=null);}}catch(e){_msg('Publish failed: $e');}finally{if(mounted)setState(()=>uploading=false);}}
  void _msg(String s)=>ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content:Text(s),behavior:SnackBarBehavior.floating));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Create Post',style:TextStyle(fontWeight:FontWeight.w800))),body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[UserAvatar(user:supabase.auth.currentUser,radius:25),const SizedBox(width:12),const Text('Share something new',style:TextStyle(fontWeight:FontWeight.w700,fontSize:17))]),const SizedBox(height:16),TextField(controller:controller,minLines:7,maxLines:12,maxLength:5000,decoration:const InputDecoration(hintText:'What do you want to share?')),const SizedBox(height:12),if(photo!=null)ClipRRect(borderRadius:BorderRadius.circular(18),child:Image.file(File(photo!.path),height:270,fit:BoxFit.cover)),if(video!=null)Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFF11131B),borderRadius:BorderRadius.circular(18)),child:Row(children:[const Icon(Icons.video_file,size:40,color:Color(0xFF9B6DFF)),const SizedBox(width:12),Expanded(child:Text(video!.name))])),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:uploading?null:pickPhoto,icon:const Icon(Icons.image_outlined),label:const Text('Photo'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:uploading?null:pickVideo,icon:const Icon(Icons.videocam_outlined),label:const Text('Video')))]),const SizedBox(height:16),SizedBox(height:54,child:FilledButton.icon(onPressed:uploading?null:publish,icon:uploading?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send_rounded),label:Text(uploading?'Publishing...':'Publish Post',style:const TextStyle(fontWeight:FontWeight.bold))))]));
  @override void dispose(){controller.dispose();super.dispose();}
}

class _CommentsSheet extends StatefulWidget { final String postId; final TextEditingController controller; const _CommentsSheet({required this.postId,required this.controller}); @override State<_CommentsSheet> createState()=>_CommentsSheetState(); }
class _CommentsSheetState extends State<_CommentsSheet>{ List<Map<String,dynamic>> rows=[]; bool loading=true,sending=false; @override void initState(){super.initState();load();} Future<void>load()async{try{final data=await supabase.from('comments').select().eq('post_id',widget.postId).order('created_at',ascending:true);if(mounted)setState(()=>rows=List<Map<String,dynamic>>.from(data));}finally{if(mounted)setState(()=>loading=false);}} Future<void>send()async{final t=widget.controller.text.trim();final uid=supabase.auth.currentUser?.id;if(t.isEmpty||uid==null)return;setState(()=>sending=true);try{await supabase.from('comments').insert({'post_id':widget.postId,'user_id':uid,'content':t});widget.controller.clear();await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Comment failed: $e')));}finally{if(mounted)setState(()=>sending=false);}} @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.viewInsetsOf(context).bottom),child:SizedBox(height:MediaQuery.sizeOf(context).height*.72,child:Column(children:[const SizedBox(height:12),Container(width:42,height:4,decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(10))),const Padding(padding:EdgeInsets.all(18),child:Text('Comments',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800))),Expanded(child:loading?const Center(child:CircularProgressIndicator()):rows.isEmpty?const _EmptyComments():ListView.builder(padding:const EdgeInsets.symmetric(horizontal:16),itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];return ListTile(leading:UserAvatar(name:'User',radius:19),title:Text(r['content']?.toString()??''),subtitle:Text(_relative(DateTime.tryParse(r['created_at']?.toString()??'')?.toLocal()??DateTime.now()),style:const TextStyle(fontSize:11,color:Colors.white38));})),Padding(padding:const EdgeInsets.all(14),child:Row(children:[Expanded(child:TextField(controller:widget.controller,minLines:1,maxLines:4,decoration:const InputDecoration(hintText:'Write a comment...'))),const SizedBox(width:8),IconButton.filled(onPressed:sending?null:send,icon:sending?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send_rounded))]))])));
}
class _EmptyComments extends StatelessWidget{const _EmptyComments();@override Widget build(BuildContext context)=>const Center(child:Text('Be the first to comment',style:TextStyle(color:Colors.white38)));}

class SearchPage extends StatefulWidget{const SearchPage({super.key});@override State<SearchPage>createState()=>_SearchPageState();}
class _SearchPageState extends State<SearchPage>{final c=TextEditingController();List<Map<String,dynamic>> users=[];bool loading=false;Future<void>search()async{final q=c.text.trim();if(q.isEmpty){setState(()=>users=[]);return;}setState(()=>loading=true);try{final data=await supabase.from('profiles').select('id,full_name,username,avatar_url').or('full_name.ilike.%$q%,username.ilike.%$q%').limit(30);setState(()=>users=List<Map<String,dynamic>>.from(data));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Search failed: $e')));}finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Search',style:TextStyle(fontWeight:FontWeight.w800))),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[TextField(controller:c,onSubmitted:(_)=>search(),decoration:InputDecoration(hintText:'Search people...',prefixIcon:const Icon(Icons.search),suffixIcon:IconButton(onPressed:search,icon:const Icon(Icons.arrow_forward_rounded)))),const SizedBox(height:16),Expanded(child:loading?const Center(child:CircularProgressIndicator()):ListView.builder(itemCount:users.length,itemBuilder:(_,i){final u=users[i];final n=u['full_name']?.toString()??'SocialBook User';return ListTile(leading:UserAvatar(url:u['avatar_url']?.toString(),name:n,radius:24),title:Text(n,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(u['username']?.toString()??''));}))])));}

class AlertsPage extends StatelessWidget{const AlertsPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Notifications',style:TextStyle(fontWeight:FontWeight.w800))),body:const _EmptyState(message:'Notifications will appear here as your community grows.'));}

class ProfilePage extends StatefulWidget{const ProfilePage({super.key});@override State<ProfilePage>createState()=>_ProfilePageState();}
class _ProfilePageState extends State<ProfilePage>{Map<String,dynamic>? p;bool loading=true;@override void initState(){super.initState();load();}Future<void>load()async{final uid=supabase.auth.currentUser?.id;if(uid==null)return;try{final d=await supabase.from('profiles').select().eq('id',uid).maybeSingle();if(mounted)setState(()=>p=d);}catch(_){}finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext context){final u=supabase.auth.currentUser;final name=p?['full_name']?.toString()??u?.userMetadata?['full_name']?.toString()??'SocialBook User';return Scaffold(appBar:AppBar(title:const Text('Profile',style:TextStyle(fontWeight:FontWeight.w800)),actions:[IconButton(onPressed:()=>showDialog(context:context,builder:(_)=>_EditProfileDialog(initialName:name,initialUsername:p?['username']?.toString()??'',onSaved:load)),icon:const Icon(Icons.edit_outlined))]),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(20),children:[Center(child:UserAvatar(url:p?['avatar_url']?.toString(),name:name,radius:58)),const SizedBox(height:14),Center(child:Text(name,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w800))),const SizedBox(height:5),Center(child:Text(u?.email??'',style:const TextStyle(color:Colors.white45))),const SizedBox(height:22),Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:const[_Stat(title:'Posts',value:'—'),_Stat(title:'Followers',value:'—'),_Stat(title:'Following',value:'—')]),const SizedBox(height:28),Card(child:Column(children:[ListTile(leading:const Icon(Icons.edit_outlined),title:const Text('Edit Profile'),onTap:()=>showDialog(context:context,builder:(_)=>_EditProfileDialog(initialName:name,initialUsername:p?['username']?.toString()??'',onSaved:load))),ListTile(leading:const Icon(Icons.bookmark_outline),title:const Text('Saved Posts'),onTap:()=>_coming(context)),ListTile(leading:const Icon(Icons.settings_outlined),title:const Text('Settings'),onTap:()=>_coming(context)),ListTile(leading:const Icon(Icons.logout,color:Colors.redAccent),title:const Text('Logout',style:TextStyle(color:Colors.redAccent)),onTap:()=>supabase.auth.signOut())])),const SizedBox(height:30),const Center(child:Text('Creator: Omor Faruk • SocialBook',style:TextStyle(color:Colors.white30,fontSize:12))) ]);}}
class _Stat extends StatelessWidget{final String title,value;const _Stat({required this.title,required this.value});@override Widget build(BuildContext context)=>Column(children:[Text(value,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:22)),const SizedBox(height:4),Text(title,style:const TextStyle(color:Colors.white45))]);}
class _EditProfileDialog extends StatefulWidget{final String initialName,initialUsername;final Future<void> Function() onSaved;const _EditProfileDialog({required this.initialName,required this.initialUsername,required this.onSaved});@override State<_EditProfileDialog>createState()=>_EditProfileDialogState();}
class _EditProfileDialogState extends State<_EditProfileDialog>{late final n=TextEditingController(text:widget.initialName);late final u=TextEditingController(text:widget.initialUsername);bool saving=false;Future<void>save()async{final uid=supabase.auth.currentUser?.id;if(uid==null)return;setState(()=>saving=true);try{await supabase.from('profiles').update({'full_name':n.text.trim(),'username':u.text.trim(),'updated_at':DateTime.now().toIso8601String()}).eq('id',uid);await supabase.auth.updateUser(UserAttributes(data:{'full_name':n.text.trim(),'username':u.text.trim()}));if(mounted){Navigator.pop(context);await widget.onSaved();}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Profile update failed: $e')));}finally{if(mounted)setState(()=>saving=false);}}@override Widget build(BuildContext context)=>AlertDialog(title:const Text('Edit Profile'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Full name')),const SizedBox(height:12),TextField(controller:u,decoration:const InputDecoration(labelText:'Username'))]),actions:[TextButton(onPressed:saving?null:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:saving?null:save,child:saving?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Text('Save'))]);}
class _EmptyState extends StatelessWidget{final String message;const _EmptyState({this.message='No posts yet. Be the first to share something!'});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(50),child:Column(children:[Icon(Icons.dynamic_feed_outlined,size:64,color:Colors.white12),const SizedBox(height:12),Text(message,textAlign:TextAlign.center,style:const TextStyle(color:Colors.white38,fontSize:15))]));}
class _ErrorState extends StatelessWidget{final VoidCallback onRetry;const _ErrorState({required this.onRetry});@override Widget build(BuildContext context)=>Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.cloud_off_outlined,size:58,color:Colors.white24),const SizedBox(height:10),const Text('Feed load করতে সমস্যা হয়েছে'),const SizedBox(height:12),FilledButton.icon(onPressed:onRetry,icon:const Icon(Icons.refresh),label:const Text('Retry'))]));}
void _coming(BuildContext c)=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('এই featureটি পরের release-এ আরও উন্নত করা হবে')));
