# SocialBook Android Build

This source package is prepared for Android build.

Project:
- App name: SocialBook
- Application ID: io.socialbook.app
- Flutter entry point: lib/main.dart

Open the project in Android Studio with Flutter support, let Gradle sync, then run:
`flutter pub get`
`flutter build apk --release`

Expected APK:
`build/app/outputs/flutter-apk/app-release.apk`

Do not put a Supabase service-role/secret key in the mobile app.
