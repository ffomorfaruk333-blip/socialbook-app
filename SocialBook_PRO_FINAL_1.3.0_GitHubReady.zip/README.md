# SocialBook Professional — Real Backend Build

This Flutter project keeps Email/Password authentication and now uses Supabase as the real backend for the social feed.

## Included
- Professional dark SocialBook UI
- Email/password signup and login
- Real Supabase profiles
- Real posts
- Real likes/unlikes
- Real comments
- Real people/post search
- Profile post count
- RLS policies
- Logo assets

## First setup
1. Open `SUPABASE_SCHEMA.sql` in Supabase SQL Editor and run it.
2. Keep Authentication -> Providers -> Email enabled.
3. Open the Flutter project and run `flutter pub get`.
4. Run the app.

See `REAL_BACKEND_SETUP.md` for the full backend setup.


## Update 1.0.2+3
- Added working email password reset flow.
- Profile now reads `full_name`, `username`, and `is_admin` from `public.profiles`.
- Admin badge is shown only when `profiles.is_admin = true`.
- Profile post count remains backed by Supabase.
- No Facebook or phone login added.
