-- Professional SocialBook upgrade. Safe to run repeatedly.
alter table if exists public.posts add column if not exists media_url text;
alter table if exists public.posts add column if not exists media_type text;
alter table if exists public.profiles add column if not exists bio text;
alter table if exists public.profiles add column if not exists username text;
alter table if exists public.profiles add column if not exists avatar_url text;

-- Existing installations may use author_id; keep the current app compatible with user_id.
alter table if exists public.posts add column if not exists user_id uuid references public.profiles(id) on delete cascade;

create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists profiles_username_idx on public.profiles(lower(username));

alter table public.posts enable row level security;
drop policy if exists "posts_select_authenticated" on public.posts;
drop policy if exists "posts_insert_own" on public.posts;
drop policy if exists "posts_update_own" on public.posts;
drop policy if exists "posts_delete_own" on public.posts;
create policy "posts_select_authenticated" on public.posts for select to authenticated using (true);
create policy "posts_insert_own" on public.posts for insert to authenticated with check (user_id = auth.uid() or author_id = auth.uid());
create policy "posts_update_own" on public.posts for update to authenticated using (user_id = auth.uid() or author_id = auth.uid()) with check (user_id = auth.uid() or author_id = auth.uid());
create policy "posts_delete_own" on public.posts for delete to authenticated using (user_id = auth.uid() or author_id = auth.uid());

alter table public.likes enable row level security;
drop policy if exists "likes_select_authenticated" on public.likes;
drop policy if exists "likes_insert_own" on public.likes;
drop policy if exists "likes_delete_own" on public.likes;
create policy "likes_select_authenticated" on public.likes for select to authenticated using (true);
create policy "likes_insert_own" on public.likes for insert to authenticated with check (user_id = auth.uid());
create policy "likes_delete_own" on public.likes for delete to authenticated using (user_id = auth.uid());

alter table public.comments enable row level security;
drop policy if exists "comments_select_authenticated" on public.comments;
drop policy if exists "comments_insert_own" on public.comments;
drop policy if exists "comments_update_own" on public.comments;
drop policy if exists "comments_delete_own" on public.comments;
create policy "comments_select_authenticated" on public.comments for select to authenticated using (true);
create policy "comments_insert_own" on public.comments for insert to authenticated with check (user_id = auth.uid());
create policy "comments_update_own" on public.comments for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "comments_delete_own" on public.comments for delete to authenticated using (user_id = auth.uid());

-- Storage bucket. If it already exists, this does nothing.
insert into storage.buckets (id, name, public) values ('post-media','post-media',true) on conflict (id) do update set public=true;

-- Authenticated users can upload only inside their own folder.
drop policy if exists "post_media_insert_own_folder" on storage.objects;
drop policy if exists "post_media_select_public" on storage.objects;
drop policy if exists "post_media_delete_own_folder" on storage.objects;
create policy "post_media_select_public" on storage.objects for select using (bucket_id='post-media');
create policy "post_media_insert_own_folder" on storage.objects for insert to authenticated with check (bucket_id='post-media' and (storage.foldername(name))[1] = 'posts' and (storage.foldername(name))[2] = auth.uid()::text);
create policy "post_media_delete_own_folder" on storage.objects for delete to authenticated using (bucket_id='post-media' and (storage.foldername(name))[1] = 'posts' and (storage.foldername(name))[2] = auth.uid()::text);
