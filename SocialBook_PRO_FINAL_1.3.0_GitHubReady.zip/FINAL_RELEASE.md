# SocialBook Final App Source — 1.0.3

Final source package prepared for Android release.

Included:
- Supabase email/password authentication
- Password reset request flow
- Existing Supabase profiles preserved
- Real posts, likes and comments
- Live feed refresh via Supabase Realtime for posts and likes
- Admin status display from profiles.is_admin
- Professional dark social UI and logo assets
- Safe, non-destructive Supabase schema/setup
- No fake/demo feed data

Android build:
1. Extract the ZIP.
2. Open the Flutter project in Android Studio/Flutter environment.
3. Run `flutter pub get`.
4. Run `flutter build apk --release`.

Important: native app code changes still require a new APK build. Backend data/content/policy changes can be updated server-side without reinstalling the app.
