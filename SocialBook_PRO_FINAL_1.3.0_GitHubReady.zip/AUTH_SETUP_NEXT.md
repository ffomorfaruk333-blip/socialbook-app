# SocialBook Auth — next step

The Flutter app now has a real Supabase AuthGate, Login, Sign Up, email confirmation handling, and Logout.

Before testing, run the existing SUPABASE_SCHEMA.sql in Supabase SQL Editor if you have not already.
Keep Authentication > Providers > Email enabled. If email confirmation is enabled, confirm the signup email before logging in.

The client uses only the publishable Supabase key. Never put a service-role/secret key in the app.
